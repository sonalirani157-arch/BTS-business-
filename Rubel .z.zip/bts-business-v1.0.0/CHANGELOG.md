# Changelog

## 1.0.0 – 2026-11-11
- Initial release: storefront, Admin Dashboard, Firebase integration
- Real-time product sync, banner/ad management, coupons
- Razorpay (UPI/cards) with server-side verification + webhook, Cash on Delivery
- Bengali and English language support
- Source Code & Updates page with versioned ZIP download
