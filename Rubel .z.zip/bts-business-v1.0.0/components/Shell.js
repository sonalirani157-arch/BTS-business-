"use client";
import { usePathname } from "next/navigation";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

// The admin area has its own layout, so the storefront chrome is hidden there.
export default function Shell({ children }) {
  const path = usePathname();
  if (path.startsWith("/admin")) return children;
  return (<><Navbar /><main>{children}</main><Footer /></>);
}
