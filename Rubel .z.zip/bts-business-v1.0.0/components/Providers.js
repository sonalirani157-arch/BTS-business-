"use client";
import { createContext, useContext, useEffect, useState, useCallback } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { doc, onSnapshot, collection, query, where, orderBy } from "firebase/firestore";
import { auth, db } from "@/lib/firebase";
import { dict } from "@/lib/i18n";

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

export const inr = (n) => "₹" + Number(n || 0).toLocaleString("en-IN");
export const priceOf = (p) => (p.salePrice > 0 ? p.salePrice : p.price);

// Wrapper that retries a failing async call with backoff (reliability requirement)
export async function withRetry(fn, tries = 3) {
  let err;
  for (let i = 0; i < tries; i++) {
    try { return await fn(); } catch (e) { err = e; await new Promise((r) => setTimeout(r, 400 * 2 ** i)); }
  }
  throw err;
}

export async function authFetch(url, body, method = "POST") {
  const token = auth.currentUser ? await auth.currentUser.getIdToken() : "";
  const res = await fetch(url, {
    method,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: method === "GET" ? undefined : JSON.stringify(body || {}),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

export default function Providers({ children }) {
  const [lang, setLang] = useState("en");
  const [user, setUser] = useState(null);
  const [role, setRole] = useState("customer");
  const [authReady, setAuthReady] = useState(false);
  const [cart, setCart] = useState([]);
  const [settings, setSettings] = useState({});
  const [banners, setBanners] = useState([]);
  const [toast, setToast] = useState("");

  // language + cart persistence (cache in localStorage)
  useEffect(() => {
    try {
      setLang(localStorage.getItem("bts_lang") || "en");
      setCart(JSON.parse(localStorage.getItem("bts_cart") || "[]"));
    } catch {}
  }, []);
  useEffect(() => { try { localStorage.setItem("bts_cart", JSON.stringify(cart)); } catch {} }, [cart]);
  useEffect(() => { try { localStorage.setItem("bts_lang", lang); } catch {}; document.documentElement.lang = lang; }, [lang]);

  // auth + role
  useEffect(() => onAuthStateChanged(auth, async (u) => {
    setUser(u);
    if (u) {
      try {
        const token = await u.getIdToken();
        const res = await fetch("/api/auth/sync", { method: "POST", headers: { Authorization: `Bearer ${token}` } });
        const d = await res.json();
        const t = await u.getIdTokenResult(d.refresh);
        setRole(t.claims.role || "customer");
      } catch { setRole("customer"); }
    } else setRole("customer");
    setAuthReady(true);
  }), []);

  // one shared listener each for site settings and banners (no duplicate reads per page)
  useEffect(() => onSnapshot(doc(db, "settings", "main"), (s) => setSettings(s.exists() ? s.data() : {}), () => {}), []);
  useEffect(() => onSnapshot(
    query(collection(db, "banners"), where("active", "==", true), orderBy("order")),
    (s) => setBanners(s.docs.map((d) => ({ id: d.id, ...d.data() }))), () => {}
  ), []);

  const t = useCallback((k) => dict[lang][k] || dict.en[k] || k, [lang]);
  const say = (m) => { setToast(m); setTimeout(() => setToast(""), 2600); };

  const addToCart = (p, qty = 1) => {
    setCart((c) => {
      const i = c.findIndex((x) => x.id === p.id);
      const max = p.stock || 1;
      if (i >= 0) { const n = [...c]; n[i] = { ...n[i], qty: Math.min(max, n[i].qty + qty), stock: p.stock }; return n; }
      return [...c, { id: p.id, name: p.name, image: (p.images || [])[0] || "", price: priceOf(p), stock: p.stock, qty }];
    });
    say("✓ " + p.name);
  };
  const setQty = (id, qty) => setCart((c) => c.map((x) => (x.id === id ? { ...x, qty: Math.max(1, Math.min(x.stock || 20, qty)) } : x)));
  const removeFromCart = (id) => setCart((c) => c.filter((x) => x.id !== id));
  const clearCart = () => setCart([]);

  return (
    <Ctx.Provider value={{ lang, setLang, t, user, role, authReady, isStaff: role === "admin" || role === "manager", isAdmin: role === "admin",
      cart, addToCart, setQty, removeFromCart, clearCart, settings, banners, say }}>
      {children}
      {toast && <div className="toast">{toast}</div>}
    </Ctx.Provider>
  );
}
