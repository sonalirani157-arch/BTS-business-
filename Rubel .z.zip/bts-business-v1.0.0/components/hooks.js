"use client";
import { useEffect, useState } from "react";
import { collection, onSnapshot } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useApp } from "@/components/Providers";

// Live set of the signed-in user's wishlisted product ids
export function useWishIds() {
  const { user } = useApp();
  const [ids, setIds] = useState(new Set());
  useEffect(() => {
    if (!user) { setIds(new Set()); return; }
    return onSnapshot(collection(db, "users", user.uid, "wishlist"), (s) => setIds(new Set(s.docs.map((d) => d.id))), () => {});
  }, [user]);
  return ids;
}

export function useCollectionLive(q, deps) {
  const [data, setData] = useState(null);
  useEffect(() => {
    setData(null);
    return onSnapshot(q(), (s) => setData(s.docs.map((d) => ({ id: d.id, ...d.data() }))), () => setData([]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return data;
}
