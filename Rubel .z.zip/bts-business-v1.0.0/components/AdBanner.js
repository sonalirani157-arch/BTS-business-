"use client";
import { useApp } from "@/components/Providers";

// Renders every active banner assigned to a placement: top | home-middle | bottom | sidebar
export default function AdBanner({ placement }) {
  const { banners } = useApp();
  const list = banners.filter((b) => b.placement === placement && b.image);
  if (!list.length) return null;
  return list.map((b) => {
    const img = <img src={b.image} alt={b.title || "Advertisement"} loading="lazy" />;
    return b.link
      ? <a key={b.id} className="ad" href={b.link} target="_blank" rel="noopener noreferrer sponsored">{img}</a>
      : <div key={b.id} className="ad">{img}</div>;
  });
}
