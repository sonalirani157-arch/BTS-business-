"use client";
import { useApp } from "@/components/Providers";
import AdBanner from "@/components/AdBanner";

export default function Footer() {
  const { settings } = useApp();
  return (
    <footer className="footer">
      <div className="container">
        <AdBanner placement="bottom" />
        <p>© {new Date().getFullYear()} {settings.storeName || "BTS BUSINESS"}. All rights reserved.</p>
        {(settings.supportEmail || settings.phone) && <p>{settings.supportEmail} {settings.phone && " · " + settings.phone}</p>}
      </div>
    </footer>
  );
}
