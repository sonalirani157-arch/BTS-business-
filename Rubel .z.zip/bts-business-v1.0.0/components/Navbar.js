"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { useApp } from "@/components/Providers";

export default function Navbar() {
  const { t, lang, setLang, user, isStaff, cart, settings } = useApp();
  const [open, setOpen] = useState(false);
  const path = usePathname();
  const count = cart.reduce((n, i) => n + i.qty, 0);
  const L = (href, label, extra) => (
    <Link href={href} className={path === href ? "on" : ""} onClick={() => setOpen(false)}>{label}{extra}</Link>
  );
  return (
    <header className="nav">
      <div className="container nav-in">
        <Link href="/" className="logo">{settings.storeName || "BTS BUSINESS"}</Link>
        <button className="burger" aria-label="menu" onClick={() => setOpen(!open)}>{open ? "✕" : "☰"}</button>
        <nav className={"links" + (open ? " open" : "")}>
          {L("/", t("home"))}
          {L("/products", t("shop"))}
          {L("/wishlist", t("wishlist"))}
          {L("/cart", t("cart"), count > 0 && <span className="badge">{count}</span>)}
          {user && L("/orders", t("orders"))}
          {L("/contact", t("contact"))}
          {isStaff && L("/admin", t("admin"))}
          {user ? <a href="#" onClick={(e) => { e.preventDefault(); signOut(auth); }}>{t("logout")}</a> : L("/login", t("login"))}
          <span className="lang">
            <button className={lang === "en" ? "on" : ""} onClick={() => setLang("en")}>EN</button>
            <button className={lang === "bn" ? "on" : ""} onClick={() => setLang("bn")}>বাং</button>
          </span>
        </nav>
      </div>
    </header>
  );
}
