"use client";
import Link from "next/link";
import { doc, setDoc, deleteDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useApp, inr, priceOf } from "@/components/Providers";

export default function ProductCard({ p, i = 0, wished, wishIds }) {
  const { t, lang, addToCart, user, say } = useApp();
  const name = (lang === "bn" && p.nameBn) || p.name;
  const sale = p.salePrice > 0 && p.salePrice < p.price;
  const isWished = wishIds ? wishIds.has(p.id) : wished;

  const toggleWish = async (e) => {
    e.preventDefault();
    if (!user) return say(t("signInFirst"));
    const ref = doc(db, "users", user.uid, "wishlist", p.id);
    try {
      if (isWished) await deleteDoc(ref);
      else await setDoc(ref, { name: p.name, image: (p.images || [])[0] || "", price: priceOf(p), at: Date.now() });
    } catch { say("Error"); }
  };

  return (
    <div className="pcard" style={{ animationDelay: Math.min(i, 8) * 60 + "ms" }}>
      {sale && <span className="tag">-{Math.round(((p.price - p.salePrice) / p.price) * 100)}%</span>}
      <button className={"heart" + (isWished ? " on" : "")} onClick={toggleWish} aria-label="wishlist">{isWished ? "♥" : "♡"}</button>
      <Link href={`/products/${p.id}`}>
        <div className="pimg">{(p.images || [])[0] && <img src={p.images[0]} alt={name} loading="lazy" />}</div>
      </Link>
      <div className="pbody">
        <Link href={`/products/${p.id}`}><h3>{name}</h3></Link>
        <div className="price">{inr(priceOf(p))}{sale && <s>{inr(p.price)}</s>}</div>
        <button className="btn sm" disabled={!(p.stock > 0)} onClick={() => addToCart({ ...p })}>
          {p.stock > 0 ? t("addToCart") : t("outOfStock")}
        </button>
      </div>
    </div>
  );
}
