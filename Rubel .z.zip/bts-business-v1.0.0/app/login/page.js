"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { useApp } from "@/components/Providers";

export default function Login() {
  const { t } = useApp();
  const router = useRouter();
  const [mode, setMode] = useState("in");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");

  const go = async (fn) => {
    setErr("");
    try { await fn(); router.push("/"); }
    catch (e) { setErr(e.message.replace("Firebase: ", "")); }
  };

  return (
    <div className="container section" style={{ maxWidth: 440 }}>
      <h2 className="section-title"><span>{mode === "in" ? t("signIn") : t("register")}</span></h2>
      <form className="card" onSubmit={(e) => { e.preventDefault(); go(() => mode === "in" ? signInWithEmailAndPassword(auth, email, pw) : createUserWithEmailAndPassword(auth, email, pw)); }}>
        <label>{t("email")}</label><input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        <label>{t("password")}</label><input type="password" required minLength="6" value={pw} onChange={(e) => setPw(e.target.value)} />
        {err && <p className="err">{err}</p>}
        <button className="btn" style={{ width: "100%", marginTop: 18 }}>{mode === "in" ? t("signIn") : t("register")}</button>
        <button type="button" className="btn ghost" style={{ width: "100%", marginTop: 10 }} onClick={() => go(() => signInWithPopup(auth, new GoogleAuthProvider()))}>{t("google")}</button>
        <p className="muted" style={{ marginTop: 16, cursor: "pointer", textAlign: "center" }} onClick={() => setMode(mode === "in" ? "up" : "in")}>
          {mode === "in" ? t("register") : t("signIn")}
        </p>
      </form>
    </div>
  );
}
