"use client";
import { useEffect, useState } from "react";
import { doc, onSnapshot, collection, query, orderBy, limit, addDoc, serverTimestamp } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useApp, inr, priceOf } from "@/components/Providers";
import { useCollectionLive } from "@/components/hooks";

export default function ProductDetail({ params }) {
  const { t, lang, addToCart, user, say } = useApp();
  const [p, setP] = useState(undefined);
  const [img, setImg] = useState(0);
  const [qty, setQty] = useState(1);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");

  useEffect(() => onSnapshot(doc(db, "products", params.id), (s) => setP(s.exists() ? { id: s.id, ...s.data() } : null), () => setP(null)), [params.id]);
  const reviews = useCollectionLive(() => query(collection(db, "products", params.id, "reviews"), orderBy("createdAt", "desc"), limit(30)), [params.id]);

  if (p === undefined) return <div className="spinner" />;
  if (!p || !p.active) return <div className="container section"><p className="muted">{t("noResults")}</p></div>;

  const name = (lang === "bn" && p.nameBn) || p.name;
  const desc = (lang === "bn" && p.descriptionBn) || p.description;
  const avg = reviews && reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0;
  const sale = p.salePrice > 0 && p.salePrice < p.price;

  const submitReview = async (e) => {
    e.preventDefault();
    if (!user) return say(t("signInFirst"));
    try {
      await addDoc(collection(db, "products", p.id, "reviews"), {
        uid: user.uid, user: user.displayName || (user.email || "").split("@")[0], rating: parseInt(rating, 10),
        comment: comment.trim().slice(0, 1000), createdAt: serverTimestamp(),
      });
      setComment("");
    } catch { say("Error"); }
  };

  return (
    <div className="container section">
      <div className="detail">
        <div className="gallery">
          <div className="main">{(p.images || [])[img] && <img key={img} src={p.images[img]} alt={name} />}</div>
          <div className="thumbs">{(p.images || []).map((u, i) => <img key={u} src={u} alt="" loading="lazy" className={i === img ? "on" : ""} onClick={() => setImg(i)} />)}</div>
        </div>
        <div>
          <h1 style={{ fontSize: "2rem" }}>{name}</h1>
          <div className="stars" style={{ margin: "8px 0" }}>{"★".repeat(Math.round(avg))}{"☆".repeat(5 - Math.round(avg))} <span className="muted">({reviews ? reviews.length : 0})</span></div>
          <div className="price" style={{ fontSize: "1.5rem" }}>{inr(priceOf(p))}{sale && <s>{inr(p.price)}</s>}</div>
          <p className="muted" style={{ margin: "14px 0", whiteSpace: "pre-line" }}>{desc}</p>
          <p style={{ marginBottom: 14 }}><span className={"pill " + (p.stock > 0 ? "ok" : "bad")}>{p.stock > 0 ? `${t("inStock")} (${p.stock})` : t("outOfStock")}</span></p>
          {p.stock > 0 && (
            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <input type="number" min="1" max={p.stock} value={qty} onChange={(e) => setQty(Math.max(1, Math.min(p.stock, +e.target.value || 1)))} style={{ width: 90 }} />
              <button className="btn" onClick={() => addToCart(p, qty)}>{t("addToCart")}</button>
            </div>
          )}
        </div>
      </div>

      <section style={{ marginTop: 56 }}>
        <h2 className="section-title"><span>{t("reviews")}</span></h2>
        <form className="card" onSubmit={submitReview} style={{ marginBottom: 20 }}>
          <label>{t("rating")}</label>
          <select value={rating} onChange={(e) => setRating(e.target.value)} style={{ maxWidth: 140 }}>{[5, 4, 3, 2, 1].map((n) => <option key={n} value={n}>{"★".repeat(n)}</option>)}</select>
          <label>{t("comment")}</label>
          <textarea rows="3" required maxLength="1000" value={comment} onChange={(e) => setComment(e.target.value)} />
          <button className="btn sm" style={{ marginTop: 12 }}>{t("submit")}</button>
        </form>
        {(reviews || []).map((r) => (
          <div key={r.id} className="card" style={{ marginBottom: 10 }}>
            <b>{r.user}</b> <span className="stars">{"★".repeat(r.rating)}</span>
            <p className="muted">{r.comment}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
