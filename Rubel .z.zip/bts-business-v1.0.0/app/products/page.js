"use client";
import { Suspense, useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { collection, query, where, orderBy, limit } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useApp } from "@/components/Providers";
import { useCollectionLive, useWishIds } from "@/components/hooks";
import ProductCard from "@/components/ProductCard";
import AdBanner from "@/components/AdBanner";

const PAGE = 12;

function Shop() {
  const { t } = useApp();
  const params = useSearchParams();
  const wishIds = useWishIds();
  const [cat, setCat] = useState(params.get("cat") || "");
  const [q, setQ] = useState("");
  const [sort, setSort] = useState("new");
  const [pages, setPages] = useState(1);

  useEffect(() => setPages(1), [cat]);

  // Paginated live query: grows by PAGE items per click, still real-time
  const rows = useCollectionLive(() => {
    const base = [collection(db, "products"), where("active", "==", true)];
    if (cat) base.push(where("category", "==", cat));
    return query(...base, orderBy("createdAt", "desc"), limit(PAGE * pages));
  }, [cat, pages]);

  // categories come from a light first-page query
  const allRows = useCollectionLive(() => query(collection(db, "products"), where("active", "==", true), orderBy("createdAt", "desc"), limit(60)), []);
  const cats = useMemo(() => [...new Set((allRows || []).map((p) => p.category).filter(Boolean))], [allRows]);

  const shown = useMemo(() => {
    let r = (rows || []).filter((p) => !q || (p.name + " " + (p.nameBn || "") + " " + (p.description || "")).toLowerCase().includes(q.toLowerCase()));
    const pr = (p) => (p.salePrice > 0 ? p.salePrice : p.price);
    if (sort === "low") r = [...r].sort((a, b) => pr(a) - pr(b));
    if (sort === "high") r = [...r].sort((a, b) => pr(b) - pr(a));
    return r;
  }, [rows, q, sort]);

  return (
    <div className="container section">
      <h2 className="section-title"><span>{t("shop")}</span></h2>
      <div className="row" style={{ marginBottom: 18 }}>
        <input placeholder={t("search")} value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="new">{t("sortNew")}</option><option value="low">{t("sortLow")}</option><option value="high">{t("sortHigh")}</option>
        </select>
      </div>
      <div className="chips" style={{ marginBottom: 24 }}>
        <button className={"chip" + (!cat ? " on" : "")} onClick={() => setCat("")}>{t("all")}</button>
        {cats.map((c) => <button key={c} className={"chip" + (cat === c ? " on" : "")} onClick={() => setCat(c)}>{c}</button>)}
      </div>
      {!rows ? <div className="spinner" /> : shown.length === 0 ? <p className="muted">{t("noResults")}</p> :
        <div className="grid">{shown.map((p, i) => <ProductCard key={p.id} p={p} i={i} wishIds={wishIds} />)}</div>}
      {rows && rows.length >= PAGE * pages && (
        <div style={{ textAlign: "center", marginTop: 30 }}><button className="btn ghost" onClick={() => setPages(pages + 1)}>{t("loadMore")}</button></div>
      )}
      <AdBanner placement="sidebar" />
    </div>
  );
}

export default function ProductsPage() {
  return <Suspense fallback={<div className="spinner" />}><Shop /></Suspense>;
}
