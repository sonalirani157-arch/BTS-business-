import "./globals.css";
import Providers from "@/components/Providers";
import Shell from "@/components/Shell";

export const metadata = {
  title: "BTS BUSINESS",
  description: "BTS BUSINESS – premium online store",
};

export const viewport = { width: "device-width", initialScale: 1 };

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <Providers>
          <Shell>{children}</Shell>
        </Providers>
      </body>
    </html>
  );
}
