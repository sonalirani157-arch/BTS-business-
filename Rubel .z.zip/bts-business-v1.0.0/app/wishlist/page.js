"use client";
import { collection, orderBy, query } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useApp } from "@/components/Providers";
import { useCollectionLive } from "@/components/hooks";
import ProductCard from "@/components/ProductCard";

export default function Wishlist() {
  const { t, user } = useApp();
  const items = useCollectionLive(
    () => query(collection(db, "users", user ? user.uid : "none", "wishlist"), orderBy("at", "desc")), [user && user.uid]);
  if (!user) return <div className="container section"><p className="muted">{t("signInFirst")}</p></div>;
  if (!items) return <div className="spinner" />;
  return (
    <div className="container section">
      <h2 className="section-title"><span>{t("wishlist")}</span></h2>
      {items.length === 0 ? <p className="muted">{t("noResults")}</p> :
        <div className="grid">{items.map((p, i) => <ProductCard key={p.id} i={i} wished p={{ ...p, images: [p.image], price: p.price, stock: 1 }} />)}</div>}
    </div>
  );
}
