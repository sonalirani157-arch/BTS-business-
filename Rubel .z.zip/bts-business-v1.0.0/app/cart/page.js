"use client";
import Link from "next/link";
import { useApp, inr } from "@/components/Providers";

export default function CartPage() {
  const { t, cart, setQty, removeFromCart } = useApp();
  const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
  if (!cart.length) return <div className="container section"><h2 className="section-title"><span>{t("cart")}</span></h2><p className="muted">{t("emptyCart")}</p><br /><Link href="/products" className="btn">{t("shopNow")}</Link></div>;
  return (
    <div className="container section">
      <h2 className="section-title"><span>{t("cart")}</span></h2>
      <div className="card table-wrap">
        <table><tbody>
          {cart.map((i) => (
            <tr key={i.id}>
              <td style={{ width: 60 }}>{i.image && <img className="thumb" src={i.image} alt="" loading="lazy" />}</td>
              <td>{i.name}</td>
              <td>{inr(i.price)}</td>
              <td style={{ width: 90 }}><input type="number" min="1" max={i.stock || 20} value={i.qty} onChange={(e) => setQty(i.id, +e.target.value || 1)} /></td>
              <td>{inr(i.price * i.qty)}</td>
              <td><button className="btn danger sm" onClick={() => removeFromCart(i.id)}>✕</button></td>
            </tr>
          ))}
        </tbody></table>
      </div>
      <p style={{ textAlign: "right", margin: "20px 0", fontSize: "1.2rem" }}>{t("subtotal")}: <b className="stars">{inr(subtotal)}</b></p>
      <div style={{ textAlign: "right" }}><Link href="/checkout" className="btn">{t("checkout")} →</Link></div>
    </div>
  );
}
