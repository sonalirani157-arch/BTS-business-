"use client";
import { useState } from "react";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useApp, withRetry } from "@/components/Providers";

export default function Contact() {
  const { t, settings, user, say } = useApp();
  const [f, setF] = useState({ name: "", email: "", message: "" });
  const submit = async (e) => {
    e.preventDefault();
    try {
      await withRetry(() => addDoc(collection(db, "tickets"), { ...f, uid: user ? user.uid : null, status: "open", createdAt: serverTimestamp() }));
      setF({ name: "", email: "", message: "" }); say(t("sent"));
    } catch { say("Error — please try again"); }
  };
  return (
    <div className="container section" style={{ maxWidth: 640 }}>
      <h2 className="section-title"><span>{t("contact")}</span></h2>
      {(settings.supportEmail || settings.phone) && <p className="muted" style={{ marginBottom: 16 }}>{settings.supportEmail} {settings.phone}</p>}
      <form className="card" onSubmit={submit}>
        <label>{t("name")}</label><input required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <label>{t("email")}</label><input type="email" required value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
        <label>{t("message")}</label><textarea required rows="5" maxLength="2000" value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} />
        <button className="btn" style={{ marginTop: 16 }}>{t("send")}</button>
      </form>
    </div>
  );
}
