"use client";
import Link from "next/link";
import { collection, query, where, orderBy, limit } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useApp } from "@/components/Providers";
import { useCollectionLive, useWishIds } from "@/components/hooks";
import ProductCard from "@/components/ProductCard";
import AdBanner from "@/components/AdBanner";

const Skeletons = () => <div className="grid">{[0, 1, 2, 3].map((i) => <div key={i} className="skel" />)}</div>;

export default function Home() {
  const { t, lang, settings } = useApp();
  const wishIds = useWishIds();
  const sec = { hero: true, categories: true, featured: true, newArrivals: true, ads: true, ...(settings.homeSections || {}) };

  // Live queries: any admin change shows up here instantly
  const featured = useCollectionLive(
    () => query(collection(db, "products"), where("active", "==", true), where("featured", "==", true), orderBy("createdAt", "desc"), limit(8)), []);
  const latest = useCollectionLive(
    () => query(collection(db, "products"), where("active", "==", true), orderBy("createdAt", "desc"), limit(8)), []);

  const cats = [...new Set((latest || []).map((p) => p.category).filter(Boolean))];
  const title = (lang === "bn" && settings.heroTitleBn) || settings.heroTitleEn || "Premium products, delivered to your door";
  const sub = (lang === "bn" && settings.heroSubBn) || settings.heroSubEn || "Discover quality you can trust with fast delivery across India.";

  return (
    <>
      <AdBanner placement="top" />
      {sec.hero && (
        <section className="hero">
          <div className="container">
            <h1>{title}</h1>
            <p>{sub}</p>
            <Link href="/products" className="btn">{t("shopNow")} →</Link>
          </div>
        </section>
      )}

      {sec.categories && cats.length > 0 && (
        <section className="section container">
          <h2 className="section-title"><span>{t("categories")}</span></h2>
          <div className="chips">{cats.map((c) => <Link key={c} href={`/products?cat=${encodeURIComponent(c)}`} className="chip">{c}</Link>)}</div>
        </section>
      )}

      {sec.featured && (
        <section className="section container">
          <h2 className="section-title"><span>{t("featured")}</span></h2>
          {!featured ? <Skeletons /> : featured.length === 0 ? <p className="muted">{t("noResults")}</p> :
            <div className="grid">{featured.map((p, i) => <ProductCard key={p.id} p={p} i={i} wishIds={wishIds} />)}</div>}
        </section>
      )}

      {sec.ads && <div className="container"><AdBanner placement="home-middle" /></div>}

      {sec.newArrivals && (
        <section className="section container">
          <h2 className="section-title"><span>{t("newArrivals")}</span></h2>
          {!latest ? <Skeletons /> :
            <div className="grid">{latest.map((p, i) => <ProductCard key={p.id} p={p} i={i} wishIds={wishIds} />)}</div>}
        </section>
      )}
    </>
  );
}
