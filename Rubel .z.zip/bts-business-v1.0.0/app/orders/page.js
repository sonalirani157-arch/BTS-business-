"use client";
import { collection, query, where, orderBy } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useApp, inr } from "@/components/Providers";
import { useCollectionLive } from "@/components/hooks";

const STEPS = ["pending", "confirmed", "packed", "shipped", "delivered"];

export default function Orders() {
  const { t, user } = useApp();
  // Live: order status changes made by admin appear instantly (order tracking)
  const orders = useCollectionLive(
    () => query(collection(db, "orders"), where("uid", "==", user ? user.uid : "none"), orderBy("createdAt", "desc")), [user && user.uid]);
  if (!user) return <div className="container section"><p className="muted">{t("signInFirst")}</p></div>;
  if (!orders) return <div className="spinner" />;
  return (
    <div className="container section">
      <h2 className="section-title"><span>{t("orders")}</span></h2>
      {orders.length === 0 && <p className="muted">{t("noResults")}</p>}
      {orders.map((o) => {
        const idx = STEPS.indexOf(o.status);
        return (
          <div className="card" key={o.id} style={{ marginBottom: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 8 }}>
              <b>#{o.id.slice(0, 8).toUpperCase()}</b>
              <span><span className={"pill " + (o.paymentStatus === "paid" ? "ok" : "")}>{t(o.paymentStatus)}</span> <b className="stars">{inr(o.total)}</b></span>
            </div>
            <p className="muted">{o.items.map((i) => `${i.name} × ${i.qty}`).join(", ")}</p>
            {o.status === "cancelled"
              ? <p className="err">{t("cancelled")}</p>
              : <div className="timeline">{STEPS.map((s, i) => <span key={s} className={"step" + (i <= idx ? " done" : "")}>{t(s)}</span>)}</div>}
          </div>
        );
      })}
    </div>
  );
}
