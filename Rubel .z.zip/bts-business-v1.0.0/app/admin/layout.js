"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useApp } from "@/components/Providers";

const NAV = [
  ["/admin", "📊 Dashboard"], ["/admin/products", "📦 Products"], ["/admin/orders", "🧾 Orders"],
  ["/admin/users", "👥 Users"], ["/admin/coupons", "🏷️ Coupons"], ["/admin/banners", "📣 Banners & Ads"],
  ["/admin/homepage", "🏠 Homepage"], ["/admin/settings", "⚙️ Settings"], ["/admin/source", "💾 Source Code & Updates"],
];

// Protected admin area: the UI is gated by role, and every write is ALSO enforced by Firestore/Storage rules and API checks.
export default function AdminLayout({ children }) {
  const { user, authReady, isStaff, isAdmin } = useApp();
  const path = usePathname();
  if (!authReady) return <div className="spinner" />;
  if (!user) return <div className="container section"><p>Please <Link href="/login" style={{ color: "var(--gold)" }}>sign in</Link> with an admin account.</p></div>;
  if (!isStaff) return <div className="container section"><h2>403</h2><p className="muted">You do not have access to this area.</p><Link href="/" className="btn sm" style={{ marginTop: 16 }}>← Store</Link></div>;
  const adminOnly = ["/admin/users", "/admin/settings", "/admin/source", "/admin/homepage"];
  const blocked = !isAdmin && adminOnly.includes(path);
  return (
    <div className="admin">
      <aside className="side">
        <Link href="/" className="logo" style={{ display: "block", margin: "0 14px 18px" }}>BTS BUSINESS</Link>
        {NAV.filter(([h]) => isAdmin || !adminOnly.includes(h)).map(([h, l]) => <Link key={h} href={h} className={path === h ? "on" : ""}>{l}</Link>)}
        <Link href="/">← Back to store</Link>
      </aside>
      <section className="main-pane">{blocked ? <p className="muted">Admins only.</p> : children}</section>
    </div>
  );
}
