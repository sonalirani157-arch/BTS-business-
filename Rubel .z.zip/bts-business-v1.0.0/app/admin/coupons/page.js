"use client";
import { useState } from "react";
import { collection, query, orderBy, limit, doc, setDoc, updateDoc, deleteDoc, Timestamp } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useCollectionLive } from "@/components/hooks";

const EMPTY = { code: "", type: "percent", value: "", minOrder: "", expires: "", active: true };

export default function AdminCoupons() {
  const coupons = useCollectionLive(() => query(collection(db, "coupons"), limit(200)), []);
  const [f, setF] = useState(EMPTY);
  const [err, setErr] = useState("");

  const add = async (e) => {
    e.preventDefault(); setErr("");
    const code = f.code.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, "");
    const value = Number(f.value);
    if (!code || !(value > 0) || (f.type === "percent" && value > 100)) return setErr("Enter a valid code and value (percent must be 1–100)");
    try {
      await setDoc(doc(db, "coupons", code), {
        code, type: f.type, value, minOrder: Number(f.minOrder || 0), active: f.active,
        expiresAt: f.expires ? Timestamp.fromDate(new Date(f.expires + "T23:59:59")) : null,
      });
      setF(EMPTY);
    } catch (e2) { setErr(e2.message); }
  };

  return (
    <>
      <h2 className="section-title"><span>Coupons</span></h2>
      <form className="card" onSubmit={add} style={{ marginBottom: 22 }}>
        <div className="row">
          <div><label>Code</label><input required value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} /></div>
          <div><label>Type</label><select value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}><option value="percent">Percent %</option><option value="flat">Flat ₹</option></select></div>
          <div><label>Value</label><input type="number" required value={f.value} onChange={(e) => setF({ ...f, value: e.target.value })} /></div>
          <div><label>Min order ₹</label><input type="number" value={f.minOrder} onChange={(e) => setF({ ...f, minOrder: e.target.value })} /></div>
          <div><label>Expires</label><input type="date" value={f.expires} onChange={(e) => setF({ ...f, expires: e.target.value })} /></div>
        </div>
        {err && <p className="err">{err}</p>}
        <button className="btn" style={{ marginTop: 16 }}>Create coupon</button>
      </form>
      {!coupons ? <div className="spinner" /> : (
        <div className="card table-wrap"><table>
          <thead><tr><th>Code</th><th>Discount</th><th>Min order</th><th>Expires</th><th>Active</th><th></th></tr></thead>
          <tbody>{coupons.map((c) => (
            <tr key={c.id}>
              <td><b>{c.code}</b></td><td>{c.type === "percent" ? c.value + "%" : "₹" + c.value}</td><td>₹{c.minOrder || 0}</td>
              <td>{c.expiresAt && c.expiresAt.toDate ? c.expiresAt.toDate().toLocaleDateString() : "—"}</td>
              <td><input type="checkbox" style={{ width: "auto" }} checked={!!c.active} onChange={(e) => updateDoc(doc(db, "coupons", c.id), { active: e.target.checked })} /></td>
              <td><button className="btn danger sm" onClick={() => confirm("Delete coupon?") && deleteDoc(doc(db, "coupons", c.id))}>Delete</button></td>
            </tr>
          ))}</tbody>
        </table></div>
      )}
    </>
  );
}
