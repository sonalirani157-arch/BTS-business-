"use client";
import { useEffect, useState } from "react";
import { doc, setDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useApp } from "@/components/Providers";

const SECTIONS = [["hero", "Hero banner"], ["categories", "Category chips"], ["featured", "Featured products"], ["ads", "Advertisement between sections"], ["newArrivals", "New arrivals"]];

export default function AdminHomepage() {
  const { settings, say } = useApp();
  const [sec, setSec] = useState({ hero: true, categories: true, featured: true, ads: true, newArrivals: true });
  const [h, setH] = useState({ heroTitleEn: "", heroTitleBn: "", heroSubEn: "", heroSubBn: "" });

  useEffect(() => {
    setSec((s) => ({ ...s, ...(settings.homeSections || {}) }));
    setH({ heroTitleEn: settings.heroTitleEn || "", heroTitleBn: settings.heroTitleBn || "", heroSubEn: settings.heroSubEn || "", heroSubBn: settings.heroSubBn || "" });
  }, [settings]);

  const save = async () => { await setDoc(doc(db, "settings", "main"), { homeSections: sec, ...h }, { merge: true }); say("Homepage saved — live now"); };
  return (
    <>
      <h2 className="section-title"><span>Homepage</span></h2>
      <div className="card" style={{ maxWidth: 700 }}>
        <h3>Sections</h3>
        {SECTIONS.map(([k, l]) => <label key={k}><input type="checkbox" style={{ width: "auto" }} checked={!!sec[k]} onChange={(e) => setSec({ ...sec, [k]: e.target.checked })} /> {l}</label>)}
        <h3 style={{ marginTop: 22 }}>Hero text</h3>
        <label>Title (English)</label><input value={h.heroTitleEn} onChange={(e) => setH({ ...h, heroTitleEn: e.target.value })} />
        <label>Title (Bengali)</label><input value={h.heroTitleBn} onChange={(e) => setH({ ...h, heroTitleBn: e.target.value })} />
        <label>Subtitle (English)</label><textarea rows="2" value={h.heroSubEn} onChange={(e) => setH({ ...h, heroSubEn: e.target.value })} />
        <label>Subtitle (Bengali)</label><textarea rows="2" value={h.heroSubBn} onChange={(e) => setH({ ...h, heroSubBn: e.target.value })} />
        <p className="muted" style={{ marginTop: 12 }}>Tip: mark products as “Featured” in Products to show them in the Featured section.</p>
        <button className="btn" style={{ marginTop: 16 }} onClick={save}>Save</button>
      </div>
    </>
  );
}
