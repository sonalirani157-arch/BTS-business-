"use client";
import { useState } from "react";
import { collection, query, orderBy, limit } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useCollectionLive } from "@/components/hooks";
import { useApp, authFetch } from "@/components/Providers";

export default function AdminUsers() {
  const { user, say } = useApp();
  const users = useCollectionLive(() => query(collection(db, "users"), orderBy("createdAt", "desc"), limit(300)), []);
  const [busy, setBusy] = useState("");

  const setRole = async (u, role) => {
    if (!confirm(`Change ${u.email} to "${role}"? They must sign in again to receive the new permissions.`)) return;
    setBusy(u.id);
    try { await authFetch("/api/admin/set-role", { uid: u.id, role }); say("Role updated"); }
    catch (e) { say(e.message); }
    setBusy("");
  };

  if (!users) return <div className="spinner" />;
  return (
    <>
      <h2 className="section-title"><span>Users</span></h2>
      <div className="card table-wrap"><table>
        <thead><tr><th>Email</th><th>Name</th><th>Joined</th><th>Role</th></tr></thead>
        <tbody>{users.map((u) => (
          <tr key={u.id}>
            <td>{u.email}</td><td>{u.name}</td>
            <td>{u.createdAt && u.createdAt.toDate ? u.createdAt.toDate().toLocaleDateString() : ""}</td>
            <td><select value={u.role || "customer"} disabled={busy === u.id || u.id === user.uid} onChange={(e) => setRole(u, e.target.value)}>
              <option value="customer">customer</option><option value="manager">manager</option><option value="admin">admin</option>
            </select></td>
          </tr>
        ))}</tbody>
      </table></div>
      <p className="muted" style={{ marginTop: 12 }}>Managers can manage products, orders, coupons and banners. Only admins can change users, settings and download the source code.</p>
    </>
  );
}
