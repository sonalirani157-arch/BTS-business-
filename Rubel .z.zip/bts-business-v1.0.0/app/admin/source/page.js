"use client";
import { useEffect, useState } from "react";
import { authFetch, useApp } from "@/components/Providers";
import { auth } from "@/lib/firebase";

export default function SourcePage() {
  const { say } = useApp();
  const [info, setInfo] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => { authFetch("/api/admin/updates", null, "GET").then(setInfo).catch((e) => setErr(e.message)); }, []);

  const download = async () => {
    setBusy(true); setErr("");
    try {
      const token = await auth.currentUser.getIdToken();
      const res = await fetch("/api/admin/source", { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || "Download failed");
      const blob = await res.blob();
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob); a.download = `bts-business-v${info.version}.zip`; a.click();
      URL.revokeObjectURL(a.href); say("Download started");
    } catch (e) { setErr(e.message); }
    setBusy(false);
  };

  return (
    <>
      <h2 className="section-title"><span>Source Code & Updates</span></h2>
      {err && <p className="err">{err}</p>}
      {!info ? <div className="spinner" /> : (
        <>
          <div className="card" style={{ marginBottom: 22 }}>
            <p className="muted">Current version</p>
            <h2 style={{ color: "var(--gold2)" }}>v{info.version}</h2>
            <p className="muted">Released {info.releasedAt}</p>
            <p style={{ margin: "14px 0" }}>The ZIP contains the full frontend + backend, Firebase rules and indexes, <code>README.md</code> (installation and deployment guide) and <code>CHANGELOG.md</code>. Secrets such as <code>.env</code> are never included — copy <code>.env.example</code> to <code>.env.local</code> and fill it in.</p>
            <button className="btn" onClick={download} disabled={busy}>{busy ? "Preparing ZIP…" : `⬇ Download source v${info.version}`}</button>
          </div>
          <div className="card">
            <h3 style={{ marginBottom: 12 }}>Update history</h3>
            {info.changelog.map((c) => (
              <div key={c.version} style={{ marginBottom: 16 }}>
                <b>v{c.version}</b> <span className="muted">— {c.date}</span>
                <ul style={{ margin: "6px 0 0 20px" }}>{c.notes.map((n, i) => <li key={i} className="muted">{n}</li>)}</ul>
              </div>
            ))}
          </div>
        </>
      )}
    </>
  );
}
