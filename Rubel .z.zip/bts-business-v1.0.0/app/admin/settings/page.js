"use client";
import { useEffect, useState } from "react";
import { doc, setDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useApp } from "@/components/Providers";

export default function AdminSettings() {
  const { settings, say } = useApp();
  const [f, setF] = useState({ storeName: "BTS BUSINESS", supportEmail: "", phone: "", shippingFee: 0, freeShippingAbove: 0, codEnabled: false });
  useEffect(() => setF((x) => ({ ...x, ...Object.fromEntries(Object.entries(settings).filter(([k]) => k in x)) })), [settings]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });
  const save = async (e) => {
    e.preventDefault();
    await setDoc(doc(db, "settings", "main"), { ...f, shippingFee: Number(f.shippingFee) || 0, freeShippingAbove: Number(f.freeShippingAbove) || 0 }, { merge: true });
    say("Settings saved");
  };
  return (
    <>
      <h2 className="section-title"><span>Settings</span></h2>
      <form className="card" style={{ maxWidth: 600 }} onSubmit={save}>
        <label>Store name</label><input value={f.storeName} onChange={set("storeName")} />
        <label>Support email</label><input type="email" value={f.supportEmail} onChange={set("supportEmail")} />
        <label>Support phone</label><input value={f.phone} onChange={set("phone")} />
        <div className="row">
          <div><label>Shipping fee (₹)</label><input type="number" value={f.shippingFee} onChange={set("shippingFee")} /></div>
          <div><label>Free shipping above (₹, 0 = never)</label><input type="number" value={f.freeShippingAbove} onChange={set("freeShippingAbove")} /></div>
        </div>
        <label><input type="checkbox" style={{ width: "auto" }} checked={!!f.codEnabled} onChange={set("codEnabled")} /> Enable Cash on Delivery</label>
        <button className="btn" style={{ marginTop: 16 }}>Save settings</button>
      </form>
    </>
  );
}
