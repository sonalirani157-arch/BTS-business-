"use client";
import { useState } from "react";
import { collection, query, orderBy, limit, doc, addDoc, updateDoc, deleteDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { uploadImage, removeImage } from "@/lib/upload";
import { useCollectionLive } from "@/components/hooks";

const PLACEMENTS = [
  ["bottom", "Bottom of every page (footer)"], ["top", "Top of homepage"],
  ["home-middle", "Homepage – between sections"], ["sidebar", "Shop page – below products"],
];

export default function AdminBanners() {
  const banners = useCollectionLive(() => query(collection(db, "banners"), orderBy("order"), limit(100)), []);
  const [f, setF] = useState({ title: "", link: "", placement: "bottom", order: 1, image: "" });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const upload = async (e, onUrl) => {
    const file = e.target.files[0]; if (!file) return;
    setBusy(true); setErr("");
    try { onUrl(await uploadImage(file, "banners")); } catch (e2) { setErr(e2.message); }
    setBusy(false);
  };
  const add = async (e) => {
    e.preventDefault();
    if (!f.image) return setErr("Upload a banner image first");
    if (f.link && !/^https?:\/\//i.test(f.link)) return setErr("Link must start with http:// or https://");
    await addDoc(collection(db, "banners"), { ...f, order: Number(f.order) || 1, active: true });
    setF({ title: "", link: "", placement: "bottom", order: 1, image: "" });
  };
  const upd = (b, patch) => updateDoc(doc(db, "banners", b.id), patch);
  const del = async (b) => { if (confirm("Delete banner?")) { await removeImage(b.image); await deleteDoc(doc(db, "banners", b.id)); } };

  return (
    <>
      <h2 className="section-title"><span>Banners & Ads</span></h2>
      <form className="card" onSubmit={add} style={{ marginBottom: 22 }}>
        <div className="row">
          <div><label>Title (alt text)</label><input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
          <div><label>Click link (optional)</label><input placeholder="https://" value={f.link} onChange={(e) => setF({ ...f, link: e.target.value })} /></div>
          <div><label>Placement</label><select value={f.placement} onChange={(e) => setF({ ...f, placement: e.target.value })}>{PLACEMENTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></div>
          <div><label>Order</label><input type="number" value={f.order} onChange={(e) => setF({ ...f, order: e.target.value })} /></div>
        </div>
        <label>Banner image</label>
        <input type="file" accept="image/*" onChange={(e) => upload(e, (u) => setF({ ...f, image: u }))} />
        {f.image && <img src={f.image} alt="" style={{ maxHeight: 90, marginTop: 10, borderRadius: 10 }} />}
        {err && <p className="err">{err}</p>}
        <button className="btn" style={{ marginTop: 16 }} disabled={busy}>{busy ? "Uploading…" : "Add banner"}</button>
      </form>
      {!banners ? <div className="spinner" /> : (
        <div className="card table-wrap"><table>
          <thead><tr><th>Image</th><th>Title / link</th><th>Placement</th><th>Order</th><th>On</th><th></th></tr></thead>
          <tbody>{banners.map((b) => (
            <tr key={b.id}>
              <td><img src={b.image} alt="" style={{ width: 120, borderRadius: 8 }} loading="lazy" /><br /><input type="file" accept="image/*" style={{ marginTop: 6 }} onChange={(e) => upload(e, (u) => upd(b, { image: u }))} /></td>
              <td>{b.title}<br /><span className="muted">{b.link}</span></td>
              <td><select value={b.placement} onChange={(e) => upd(b, { placement: e.target.value })}>{PLACEMENTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></td>
              <td><input type="number" style={{ width: 70 }} defaultValue={b.order} onBlur={(e) => upd(b, { order: Number(e.target.value) || 1 })} /></td>
              <td><input type="checkbox" style={{ width: "auto" }} checked={!!b.active} onChange={(e) => upd(b, { active: e.target.checked })} /></td>
              <td><button className="btn danger sm" onClick={() => del(b)}>Delete</button></td>
            </tr>
          ))}</tbody>
        </table></div>
      )}
    </>
  );
}
