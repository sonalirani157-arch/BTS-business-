"use client";
import { collection, query, orderBy, limit, doc, updateDoc, arrayUnion } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useCollectionLive } from "@/components/hooks";
import { inr } from "@/components/Providers";

const STATUSES = ["pending", "confirmed", "packed", "shipped", "delivered", "cancelled"];

export default function AdminOrders() {
  const orders = useCollectionLive(() => query(collection(db, "orders"), orderBy("createdAt", "desc"), limit(200)), []);

  const setStatus = (o, status) => updateDoc(doc(db, "orders", o.id), { status, timeline: arrayUnion({ status, at: Date.now() }) });
  // COD orders are collected on delivery, so admin can mark them paid
  const markPaid = (o) => updateDoc(doc(db, "orders", o.id), { paymentStatus: "paid" });

  if (!orders) return <div className="spinner" />;
  return (
    <>
      <h2 className="section-title"><span>Orders</span></h2>
      <div className="card table-wrap"><table>
        <thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th></tr></thead>
        <tbody>{orders.map((o) => (
          <tr key={o.id}>
            <td>#{o.id.slice(0, 8).toUpperCase()}<br /><span className="muted">{o.createdAt && o.createdAt.toDate ? o.createdAt.toDate().toLocaleString() : ""}</span></td>
            <td>{o.address.name}<br /><span className="muted">{o.address.phone}<br />{o.address.line1}, {o.address.city} {o.address.pin}</span></td>
            <td>{o.items.map((i) => `${i.name} × ${i.qty}`).join(", ")}</td>
            <td>{inr(o.total)}{o.coupon && <><br /><span className="pill">{o.coupon}</span></>}</td>
            <td>
              <span className={"pill " + (o.paymentStatus === "paid" ? "ok" : "bad")}>{o.paymentStatus}</span> <span className="pill">{o.method}</span>
              {o.paymentStatus !== "paid" && o.method === "cod" && <><br /><button className="btn ghost sm" style={{ marginTop: 6 }} onClick={() => markPaid(o)}>Mark paid</button></>}
            </td>
            <td><select value={o.status} onChange={(e) => setStatus(o, e.target.value)}>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select></td>
          </tr>
        ))}</tbody>
      </table></div>
    </>
  );
}
