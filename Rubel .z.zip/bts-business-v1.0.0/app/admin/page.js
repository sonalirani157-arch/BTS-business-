"use client";
import { collection, query, orderBy, limit } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useCollectionLive } from "@/components/hooks";
import { inr } from "@/components/Providers";

export default function Dashboard() {
  // Live sales stats from the latest 500 orders (kept bounded to limit reads)
  const orders = useCollectionLive(() => query(collection(db, "orders"), orderBy("createdAt", "desc"), limit(500)), []);
  const products = useCollectionLive(() => query(collection(db, "products"), limit(500)), []);
  const users = useCollectionLive(() => query(collection(db, "users"), limit(500)), []);
  if (!orders || !products || !users) return <div className="spinner" />;

  const valid = orders.filter((o) => o.status !== "cancelled");
  const paid = valid.filter((o) => o.paymentStatus === "paid" || (o.method === "cod" && o.status === "delivered"));
  const revenue = paid.reduce((s, o) => s + o.total, 0);
  const pending = orders.filter((o) => o.status === "pending" || o.status === "confirmed").length;
  const low = products.filter((p) => p.active && p.stock <= 5);

  const days = [...Array(7)].map((_, i) => { const d = new Date(); d.setDate(d.getDate() - (6 - i)); d.setHours(0, 0, 0, 0); return d; });
  const series = days.map((d) => {
    const end = d.getTime() + 864e5;
    return paid.filter((o) => { const t = o.createdAt && o.createdAt.toMillis ? o.createdAt.toMillis() : 0; return t >= d.getTime() && t < end; }).reduce((s, o) => s + o.total, 0);
  });
  const max = Math.max(...series, 1);

  const top = {};
  valid.forEach((o) => o.items.forEach((i) => { top[i.name] = (top[i.name] || 0) + i.qty; }));
  const topList = Object.entries(top).sort((a, b) => b[1] - a[1]).slice(0, 5);

  return (
    <>
      <h2 className="section-title"><span>Dashboard</span></h2>
      <div className="stat">
        <div className="card"><span className="muted">Revenue (paid)</span><b>{inr(revenue)}</b></div>
        <div className="card"><span className="muted">Orders</span><b>{orders.length}</b></div>
        <div className="card"><span className="muted">Open orders</span><b>{pending}</b></div>
        <div className="card"><span className="muted">Products</span><b>{products.length}</b></div>
        <div className="card"><span className="muted">Users</span><b>{users.length}</b></div>
      </div>
      <div className="row" style={{ gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))" }}>
        <div className="card">
          <h3 style={{ marginBottom: 14 }}>Sales – last 7 days</h3>
          <div className="bars" style={{ marginBottom: 28 }}>
            {series.map((v, i) => <div key={i} title={inr(v)} style={{ height: (v / max) * 100 + "%" }}><span>{days[i].getDate()}/{days[i].getMonth() + 1}</span></div>)}
          </div>
        </div>
        <div className="card">
          <h3 style={{ marginBottom: 10 }}>Top products</h3>
          {topList.length === 0 && <p className="muted">No sales yet</p>}
          {topList.map(([n, q]) => <p key={n}>{n} <span className="pill">{q} sold</span></p>)}
          <h3 style={{ margin: "18px 0 10px" }}>Low stock (≤ 5)</h3>
          {low.length === 0 && <p className="muted">All good</p>}
          {low.map((p) => <p key={p.id}>{p.name} <span className="pill bad">{p.stock}</span></p>)}
        </div>
      </div>
    </>
  );
}
