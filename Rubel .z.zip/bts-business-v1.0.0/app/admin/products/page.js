"use client";
import { useState } from "react";
import { collection, query, orderBy, limit, doc, addDoc, updateDoc, deleteDoc, serverTimestamp } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { uploadImage, removeImage } from "@/lib/upload";
import { useCollectionLive } from "@/components/hooks";
import { inr, withRetry } from "@/components/Providers";

const EMPTY = { name: "", nameBn: "", description: "", descriptionBn: "", category: "", price: "", salePrice: "", stock: "", images: [], active: true, featured: false };

export default function AdminProducts() {
  const products = useCollectionLive(() => query(collection(db, "products"), orderBy("createdAt", "desc"), limit(300)), []);
  const [f, setF] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [search, setSearch] = useState("");

  const cats = [...new Set((products || []).map((p) => p.category).filter(Boolean))];
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });

  const onFiles = async (e) => {
    setBusy(true); setErr("");
    try {
      const urls = [];
      for (const file of e.target.files) urls.push(await uploadImage(file, "products"));
      setF((x) => ({ ...x, images: [...x.images, ...urls] }));
    } catch (e2) { setErr(e2.message); }
    setBusy(false);
  };

  const save = async (e) => {
    e.preventDefault();
    const price = Number(f.price), sale = Number(f.salePrice || 0), stock = parseInt(f.stock, 10);
    if (!f.name.trim() || !(price > 0) || !(stock >= 0) || sale < 0 || (sale && sale >= price)) return setErr("Check name, price (>0), sale price (< price) and stock");
    setBusy(true); setErr("");
    const data = { name: f.name.trim(), nameBn: f.nameBn.trim(), description: f.description, descriptionBn: f.descriptionBn, category: f.category.trim(),
      price, salePrice: sale, stock, images: f.images, active: !!f.active, featured: !!f.featured, updatedAt: serverTimestamp() };
    try {
      if (f.id) await withRetry(() => updateDoc(doc(db, "products", f.id), data));
      else await withRetry(() => addDoc(collection(db, "products"), { ...data, createdAt: serverTimestamp() }));
      setF(null);
    } catch (e2) { setErr(e2.message); }
    setBusy(false);
  };

  const del = async (p) => {
    if (!confirm(`Delete "${p.name}"? This removes it from the live site immediately.`)) return;
    for (const u of p.images || []) await removeImage(u);
    await deleteDoc(doc(db, "products", p.id));
  };
  const quick = (p, patch) => updateDoc(doc(db, "products", p.id), patch);

  if (f) return (
    <form onSubmit={save} className="card" style={{ maxWidth: 760 }}>
      <h3>{f.id ? "Edit product" : "New product"}</h3>
      <div className="row">
        <div><label>Name (English)</label><input required value={f.name} onChange={set("name")} /></div>
        <div><label>Name (Bengali)</label><input value={f.nameBn} onChange={set("nameBn")} /></div>
      </div>
      <label>Description (English)</label><textarea rows="3" value={f.description} onChange={set("description")} />
      <label>Description (Bengali)</label><textarea rows="3" value={f.descriptionBn} onChange={set("descriptionBn")} />
      <div className="row">
        <div><label>Category</label><input list="cats" value={f.category} onChange={set("category")} /><datalist id="cats">{cats.map((c) => <option key={c} value={c} />)}</datalist></div>
        <div><label>Price (₹)</label><input type="number" step="0.01" required value={f.price} onChange={set("price")} /></div>
        <div><label>Sale price (₹, optional)</label><input type="number" step="0.01" value={f.salePrice} onChange={set("salePrice")} /></div>
        <div><label>Stock</label><input type="number" required value={f.stock} onChange={set("stock")} /></div>
      </div>
      <label>Images (first image is the cover)</label>
      <input type="file" accept="image/*" multiple onChange={onFiles} />
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 10 }}>
        {f.images.map((u, i) => (
          <div key={u} style={{ position: "relative" }}>
            <img className="thumb" style={{ width: 80, height: 80 }} src={u} alt="" />
            <button type="button" className="btn danger sm" style={{ position: "absolute", top: -8, right: -8, padding: "0 8px" }} onClick={() => setF({ ...f, images: f.images.filter((_, j) => j !== i) })}>✕</button>
          </div>
        ))}
      </div>
      <label><input type="checkbox" style={{ width: "auto" }} checked={f.active} onChange={set("active")} /> Visible on website</label>
      <label><input type="checkbox" style={{ width: "auto" }} checked={f.featured} onChange={set("featured")} /> Featured on homepage</label>
      {err && <p className="err">{err}</p>}
      <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
        <button className="btn" disabled={busy}>{busy ? "Saving…" : "Save"}</button>
        <button type="button" className="btn ghost" onClick={() => { setF(null); setErr(""); }}>Cancel</button>
      </div>
    </form>
  );

  const rows = (products || []).filter((p) => !search || p.name.toLowerCase().includes(search.toLowerCase()));
  return (
    <>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap", marginBottom: 18 }}>
        <h2 className="section-title" style={{ margin: 0 }}><span>Products</span></h2>
        <div style={{ display: "flex", gap: 10 }}>
          <input placeholder="Search…" value={search} onChange={(e) => setSearch(e.target.value)} />
          <button className="btn" onClick={() => setF({ ...EMPTY })}>+ Add</button>
        </div>
      </div>
      {!products ? <div className="spinner" /> : (
        <div className="card table-wrap"><table>
          <thead><tr><th></th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Live</th><th>Featured</th><th></th></tr></thead>
          <tbody>{rows.map((p) => (
            <tr key={p.id}>
              <td>{(p.images || [])[0] && <img className="thumb" src={p.images[0]} alt="" loading="lazy" />}</td>
              <td>{p.name}</td><td>{p.category}</td>
              <td>{inr(p.salePrice > 0 ? p.salePrice : p.price)}</td>
              <td><span className={"pill " + (p.stock > 5 ? "ok" : "bad")}>{p.stock}</span></td>
              <td><input type="checkbox" style={{ width: "auto" }} checked={!!p.active} onChange={(e) => quick(p, { active: e.target.checked })} /></td>
              <td><input type="checkbox" style={{ width: "auto" }} checked={!!p.featured} onChange={(e) => quick(p, { featured: e.target.checked })} /></td>
              <td style={{ whiteSpace: "nowrap" }}>
                <button className="btn ghost sm" onClick={() => setF({ ...EMPTY, ...p, price: p.price, salePrice: p.salePrice || "", stock: p.stock })}>Edit</button>{" "}
                <button className="btn danger sm" onClick={() => del(p)}>Delete</button>
              </td>
            </tr>
          ))}</tbody>
        </table></div>
      )}
    </>
  );
}
