"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useApp, inr, authFetch } from "@/components/Providers";

function loadRazorpay() {
  return new Promise((res, rej) => {
    if (window.Razorpay) return res();
    const s = document.createElement("script");
    s.src = "https://checkout.razorpay.com/v1/checkout.js";
    s.onload = res; s.onerror = () => rej(new Error("Could not load payment gateway"));
    document.body.appendChild(s);
  });
}

export default function Checkout() {
  const { t, user, authReady, cart, clearCart, settings, say } = useApp();
  const router = useRouter();
  const [addr, setAddr] = useState({ name: "", phone: "", line1: "", city: "", state: "", pin: "" });
  const [method, setMethod] = useState("razorpay");
  const [code, setCode] = useState("");
  const [price, setPrice] = useState(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const items = cart.map((i) => ({ id: i.id, qty: i.qty }));

  // server-calculated totals (never trust browser prices)
  const reprice = async (c) => {
    try {
      const r = await fetch("/api/cart/price", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ items, coupon: c }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error);
      setPrice(d); setErr("");
    } catch (e) { setErr(e.message); }
  };
  useEffect(() => { if (cart.length) reprice(price && price.coupon); /* eslint-disable-next-line */ }, [cart.length]);

  if (authReady && !user) return <div className="container section"><p className="muted">{t("signInFirst")}</p><br /><Link className="btn" href="/login">{t("login")}</Link></div>;
  if (!cart.length) return <div className="container section"><p className="muted">{t("emptyCart")}</p></div>;

  const set = (k) => (e) => setAddr({ ...addr, [k]: e.target.value });

  const place = async (e) => {
    e.preventDefault(); setBusy(true); setErr("");
    try {
      const d = await authFetch("/api/orders/create", { items, coupon: price && price.coupon, address: addr, method });
      if (d.method === "cod") { clearCart(); say(t("orderPlaced")); return router.push("/orders"); }
      await loadRazorpay();
      const rz = new window.Razorpay({
        key: d.razorpay.key, amount: d.razorpay.amount, currency: d.razorpay.currency, order_id: d.razorpay.orderId,
        name: settings.storeName || "BTS BUSINESS", prefill: { name: addr.name, contact: addr.phone, email: user.email },
        theme: { color: "#d4af37" },
        handler: async (r) => {
          try {
            await authFetch("/api/payments/verify", { orderId: d.orderId, ...r });
            clearCart(); say(t("orderPlaced")); router.push("/orders");
          } catch (e2) { setErr(e2.message); setBusy(false); }
        },
        modal: { ondismiss: () => setBusy(false) },
      });
      rz.open();
    } catch (e2) { setErr(e2.message); setBusy(false); }
  };

  return (
    <div className="container section">
      <h2 className="section-title"><span>{t("checkout")}</span></h2>
      <form onSubmit={place} className="detail">
        <div className="card">
          <label>{t("name")}</label><input required value={addr.name} onChange={set("name")} />
          <label>{t("phone")}</label><input required inputMode="numeric" value={addr.phone} onChange={set("phone")} />
          <label>{t("address")}</label><input required value={addr.line1} onChange={set("line1")} />
          <div className="row">
            <div><label>{t("city")}</label><input required value={addr.city} onChange={set("city")} /></div>
            <div><label>{t("state")}</label><input required value={addr.state} onChange={set("state")} /></div>
            <div><label>{t("pin")}</label><input required inputMode="numeric" maxLength="6" value={addr.pin} onChange={set("pin")} /></div>
          </div>
        </div>
        <div className="card">
          <label>{t("coupon")}</label>
          <div style={{ display: "flex", gap: 8 }}>
            <input value={code} onChange={(e) => setCode(e.target.value)} />
            <button type="button" className="btn ghost sm" onClick={() => reprice(code)}>{t("apply")}</button>
          </div>
          {price && (<div style={{ margin: "18px 0" }}>
            <p>{t("subtotal")}: {inr(price.subtotal)}</p>
            {price.discount > 0 && <p>{t("discount")}: -{inr(price.discount)}</p>}
            <p>{t("shipping")}: {price.shipping ? inr(price.shipping) : t("free")}</p>
            <h3 className="stars">{t("total")}: {inr(price.total)}</h3>
          </div>)}
          <label><input type="radio" style={{ width: "auto" }} checked={method === "razorpay"} onChange={() => setMethod("razorpay")} /> {t("payOnline")}</label>
          {settings.codEnabled && <label><input type="radio" style={{ width: "auto" }} checked={method === "cod"} onChange={() => setMethod("cod")} /> {t("cod")}</label>}
          {err && <p className="err">{err}</p>}
          <button className="btn" style={{ marginTop: 18, width: "100%" }} disabled={busy || !price}>{busy ? "…" : t("placeOrder")}</button>
        </div>
      </form>
    </div>
  );
}
