import Razorpay from "razorpay";
import { adminDb, FieldValue, verifyUser, json } from "@/lib/server";
import { priceCart } from "@/lib/pricing";

export const runtime = "nodejs";

const clean = (v, max = 200) => String(v || "").trim().slice(0, max);

export async function POST(req) {
  const user = await verifyUser(req);
  if (!user) return json({ error: "Please sign in to place an order" }, 401);

  try {
    const body = await req.json();
    const a = body.address || {};
    const address = {
      name: clean(a.name, 80), phone: clean(a.phone, 15), line1: clean(a.line1, 200),
      city: clean(a.city, 80), state: clean(a.state, 80), pin: clean(a.pin, 10),
    };
    if (!address.name || !/^\d{10}$/.test(address.phone.replace(/\D/g, "").slice(-10)) || !address.line1 || !address.city || !/^\d{6}$/.test(address.pin))
      return json({ error: "Please enter a valid name, 10-digit phone, address, city and 6-digit PIN" }, 400);

    const method = body.method === "cod" ? "cod" : "razorpay";
    const priced = await priceCart(body.items, body.coupon);
    if (method === "cod" && !priced.settings.codEnabled) return json({ error: "Cash on Delivery is not available" }, 400);

    const ref = adminDb.collection("orders").doc();
    const base = {
      uid: user.uid, email: user.email || "", items: priced.lines, address,
      subtotal: priced.subtotal, discount: priced.discount, shipping: priced.shipping, total: priced.total,
      coupon: priced.coupon, method, paymentStatus: "unpaid", status: "pending",
      timeline: [{ status: "pending", at: Date.now() }], createdAt: FieldValue.serverTimestamp(),
    };

    if (method === "cod") {
      await ref.set({ ...base, status: "confirmed", timeline: [{ status: "confirmed", at: Date.now() }] });
      // reserve stock immediately for COD
      await adminDb.runTransaction(async (tx) => {
        const refs = priced.lines.map((l) => adminDb.collection("products").doc(l.id));
        const snaps = await Promise.all(refs.map((r) => tx.get(r)));
        snaps.forEach((s, i) => tx.update(refs[i], { stock: Math.max(0, (s.data().stock || 0) - priced.lines[i].qty) }));
      });
      return json({ orderId: ref.id, method: "cod" });
    }

    const rzp = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });
    const rzpOrder = await rzp.orders.create({
      amount: Math.round(priced.total * 100), currency: "INR", receipt: ref.id, notes: { orderId: ref.id },
    });
    await ref.set({ ...base, rzpOrderId: rzpOrder.id });
    return json({
      orderId: ref.id, method: "razorpay",
      razorpay: { key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID, orderId: rzpOrder.id, amount: rzpOrder.amount, currency: "INR" },
    });
  } catch (e) {
    return json({ error: e.message || "Could not create order" }, 400);
  }
}
