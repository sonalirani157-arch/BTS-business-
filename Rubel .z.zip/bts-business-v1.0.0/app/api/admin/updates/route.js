import fs from "fs";
import path from "path";
import { requireRole, json } from "@/lib/server";

export const runtime = "nodejs";

export async function GET(req) {
  if (!(await requireRole(req, ["admin"]))) return json({ error: "Forbidden" }, 403);
  const v = JSON.parse(fs.readFileSync(path.join(process.cwd(), "version.json"), "utf8"));
  return json(v);
}
