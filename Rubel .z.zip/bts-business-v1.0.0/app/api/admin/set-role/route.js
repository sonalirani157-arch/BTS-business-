import { adminAuth, adminDb, requireRole, json } from "@/lib/server";

export const runtime = "nodejs";

// Admin-only: set a user's role (admin | manager | customer)
export async function POST(req) {
  const me = await requireRole(req, ["admin"]);
  if (!me) return json({ error: "Forbidden" }, 403);
  const { uid, role } = await req.json();
  if (!uid || !["admin", "manager", "customer"].includes(role)) return json({ error: "Invalid input" }, 400);
  if (uid === me.uid && role !== "admin") return json({ error: "You cannot demote yourself" }, 400);
  await adminAuth.setCustomUserClaims(uid, { role });
  await adminDb.collection("users").doc(uid).update({ role });
  return json({ ok: true });
}
