import fs from "fs";
import path from "path";
import { PassThrough } from "stream";
import { Readable } from "stream";
import archiver from "archiver";
import { requireRole, json } from "@/lib/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const SKIP = new Set(["node_modules", ".next", ".git", ".vercel", ".env", ".env.local", ".env.production"]);

function addDir(zip, dir, base) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (SKIP.has(entry.name) || /^serviceAccount.*\.json$/.test(entry.name) || entry.name.endsWith(".zip")) continue;
    const full = path.join(dir, entry.name);
    const rel = path.join(base, entry.name);
    if (entry.isDirectory()) addDir(zip, full, rel);
    else zip.file(full, { name: rel });
  }
}

// Streams the latest complete source package. Secrets (.env, service account keys) are never included.
export async function GET(req) {
  if (!(await requireRole(req, ["admin"]))) return json({ error: "Forbidden" }, 403);
  const root = process.cwd();
  const { version } = JSON.parse(fs.readFileSync(path.join(root, "version.json"), "utf8"));
  const name = `bts-business-v${version}`;

  const zip = archiver("zip", { zlib: { level: 9 } });
  const out = new PassThrough();
  zip.on("error", (e) => out.destroy(e));
  zip.pipe(out);
  addDir(zip, root, name);
  zip.finalize();

  return new Response(Readable.toWeb(out), {
    headers: {
      "Content-Type": "application/zip",
      "Content-Disposition": `attachment; filename="${name}.zip"`,
      "Cache-Control": "no-store",
    },
  });
}
