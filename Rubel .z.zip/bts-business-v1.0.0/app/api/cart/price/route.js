import { json } from "@/lib/server";
import { priceCart } from "@/lib/pricing";

export const runtime = "nodejs";

export async function POST(req) {
  try {
    const { items, coupon } = await req.json();
    const r = await priceCart(items, coupon);
    return json({ subtotal: r.subtotal, discount: r.discount, shipping: r.shipping, total: r.total, coupon: r.coupon });
  } catch (e) {
    return json({ error: e.message }, 400);
  }
}
