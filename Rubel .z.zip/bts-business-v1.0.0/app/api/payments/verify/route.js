import crypto from "crypto";
import Razorpay from "razorpay";
import { adminDb, verifyUser, json } from "@/lib/server";
import { finalizePaidOrder } from "@/lib/orders";

export const runtime = "nodejs";

// Verifies the Razorpay signature on the server, then confirms the payment with Razorpay itself.
export async function POST(req) {
  const user = await verifyUser(req);
  if (!user) return json({ error: "Unauthorized" }, 401);
  try {
    const { orderId, razorpay_order_id, razorpay_payment_id, razorpay_signature } = await req.json();
    const snap = await adminDb.collection("orders").doc(String(orderId)).get();
    if (!snap.exists || snap.data().uid !== user.uid) return json({ error: "Order not found" }, 404);
    if (snap.data().rzpOrderId !== razorpay_order_id) return json({ error: "Order mismatch" }, 400);

    const expected = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest("hex");
    const a = Buffer.from(expected), b = Buffer.from(String(razorpay_signature || ""));
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return json({ error: "Invalid payment signature" }, 400);

    const rzp = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });
    const pay = await rzp.payments.fetch(razorpay_payment_id);
    if (pay.order_id !== razorpay_order_id || pay.amount !== Math.round(snap.data().total * 100) || !["captured", "authorized"].includes(pay.status))
      return json({ error: "Payment could not be confirmed" }, 400);

    await finalizePaidOrder(snap.id, razorpay_payment_id);
    return json({ ok: true });
  } catch (e) {
    return json({ error: e.message || "Verification failed" }, 400);
  }
}
