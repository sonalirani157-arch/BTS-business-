import crypto from "crypto";
import { adminDb, json } from "@/lib/server";
import { finalizePaidOrder } from "@/lib/orders";

export const runtime = "nodejs";

// Razorpay webhook: covers customers who close the tab after paying. Set event "payment.captured".
export async function POST(req) {
  const raw = await req.text();
  const sig = req.headers.get("x-razorpay-signature") || "";
  const expected = crypto.createHmac("sha256", process.env.RAZORPAY_WEBHOOK_SECRET || "").update(raw).digest("hex");
  const a = Buffer.from(expected), b = Buffer.from(sig);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return json({ error: "Bad signature" }, 400);

  const evt = JSON.parse(raw);
  if (evt.event === "payment.captured") {
    const p = evt.payload.payment.entity;
    const orderId = p.notes && p.notes.orderId;
    if (orderId) {
      const snap = await adminDb.collection("orders").doc(orderId).get();
      if (snap.exists && snap.data().rzpOrderId === p.order_id && Math.round(snap.data().total * 100) === p.amount) {
        await finalizePaidOrder(orderId, p.id);
      }
    }
  }
  return json({ ok: true });
}
