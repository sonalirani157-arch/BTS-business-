import { adminAuth, adminDb, FieldValue, verifyUser, json } from "@/lib/server";

export const runtime = "nodejs";

// Called after every sign-in: creates the profile and grants admin to the bootstrap email.
export async function POST(req) {
  const u = await verifyUser(req);
  if (!u) return json({ error: "Unauthorized" }, 401);
  const ref = adminDb.collection("users").doc(u.uid);
  const snap = await ref.get();
  let role = u.role || "customer";
  let refresh = false;

  const boot = (process.env.ADMIN_BOOTSTRAP_EMAIL || "").toLowerCase();
  if (boot && u.email && u.email.toLowerCase() === boot && u.email_verified !== false && role !== "admin") {
    await adminAuth.setCustomUserClaims(u.uid, { role: "admin" });
    role = "admin";
    refresh = true;
  }
  if (!snap.exists) {
    await ref.set({
      uid: u.uid,
      email: u.email || "",
      name: u.name || "",
      role,
      createdAt: FieldValue.serverTimestamp(),
    });
  } else if (snap.data().role !== role) {
    await ref.update({ role });
  }
  return json({ role, refresh });
}
