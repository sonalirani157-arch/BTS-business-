# BTS BUSINESS – E-Commerce Platform

Next.js 14 + Firebase (Auth, Firestore, Storage) + Razorpay (UPI / cards / netbanking) + Cash on Delivery.
Bengali / English storefront, full Admin Dashboard, real-time product sync.

## 1. Requirements
- Node.js 18.17+ (20 LTS recommended)
- A Firebase project, a Razorpay account (Test mode works for development)

## 2. Firebase setup
1. Firebase Console → create a project.
2. **Authentication** → Sign-in method → enable **Email/Password** and **Google**.
3. **Firestore Database** → create (production mode, nearest region).
4. **Storage** → get started.
5. Project settings → Your apps → add a **Web app** → copy the config into `.env.local` (`NEXT_PUBLIC_FIREBASE_*`).
6. Project settings → Service accounts → **Generate new private key** → copy `project_id`, `client_email`, `private_key` into `FIREBASE_ADMIN_*`.
7. Deploy rules and indexes:
   ```bash
   npm i -g firebase-tools
   firebase login
   firebase use --add          # pick your project
   firebase deploy --only firestore:rules,firestore:indexes,storage
   ```
   Indexes take a few minutes to build; product lists show empty until they are ready.

## 3. Razorpay setup
1. Dashboard → Settings → API Keys → generate keys → set `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET` and `NEXT_PUBLIC_RAZORPAY_KEY_ID` (same as key id).
2. Dashboard → Settings → Webhooks → add `https://YOUR-DOMAIN/api/payments/webhook`, event **payment.captured**, and set the secret as `RAZORPAY_WEBHOOK_SECRET`.
3. UPI is enabled by default in Razorpay Checkout; enable other methods in the dashboard.

## 4. Run locally
```bash
cp .env.example .env.local     # fill in every value
npm install
npm run dev                    # http://localhost:3000
```
Set `ADMIN_BOOTSTRAP_EMAIL` to your email, register/sign in with it → you become **admin** and see **Admin** in the menu (sign out and in once if the link does not appear).

## 5. First steps in the Admin Dashboard
1. **Settings** → store name, shipping fee, enable Cash on Delivery if wanted.
2. **Products** → add products with images. They appear on the live site instantly.
3. **Banners & Ads** → upload banners; choose placement (footer/bottom, homepage top, middle, shop page).
4. **Homepage** → toggle sections, edit hero text.
5. **Users** → promote staff to `manager` (products/orders/coupons/banners) or `admin` (everything).

## 6. Deploy
Any Node host works.
- **VPS / Docker / Render / Railway:** `npm install && npm run build && npm start`; set all env vars on the host.
- **Vercel:** import the repo, add env vars, deploy. Note: the in-dashboard *Source Code & Updates* ZIP builder reads project files at runtime, which Vercel does not ship; on Vercel, download source from your Git repo or use a Node host for that feature.
- Add your domain to Firebase Console → Authentication → Settings → **Authorized domains**.

## 7. Security model
- Prices, stock, coupons and totals are computed **on the server** (`/api/orders/create`); browsers cannot set prices.
- Razorpay payments are verified server-side (HMAC signature + payment fetch + amount check) and by webhook.
- Roles use Firebase custom claims (`admin`, `manager`); Firestore and Storage rules enforce them independently of the UI.
- Orders can only be created by the server; customers can only read their own orders.
- Secrets never reach the browser or the downloadable ZIP (`.env*`, service-account keys are excluded).

## 8. Backups
Enable scheduled Firestore exports:
```bash
gcloud firestore export gs://YOUR-BUCKET/backups/$(date +%F)
```
Schedule with Cloud Scheduler, or enable Firestore point-in-time recovery in the Firebase console.

## 9. Releasing an update
1. Make changes.
2. Edit `version.json`: bump `version`, set `releasedAt`, add an entry at the top of `changelog`.
3. Mirror it in `CHANGELOG.md`.
4. Redeploy. In **Admin → Source Code & Updates** download the new `bts-business-vX.Y.Z.zip`.

## 10. Project structure
```
app/            pages (storefront), app/admin (dashboard), app/api (secure server routes)
components/     Navbar, Footer, ProductCard, AdBanner, Providers (auth, cart, language, live settings)
lib/            firebase (client), server (admin SDK), pricing, orders, i18n, upload
firestore.rules / storage.rules / firestore.indexes.json / firebase.json
version.json    version + changelog shown in the dashboard
```
